package pub.rj.paper.exception;

public class UnableToClusterInTwoException extends Exception {
	/**
	 ********************
	 * The constructor
	 * 
	 * @param paraMessage
	 *            The message to display.
	 ********************
	 */
	public UnableToClusterInTwoException(String paraMessage) {
		super(paraMessage);
	}// Of the constructor

}// Of class UnableToCluserInTwoException
